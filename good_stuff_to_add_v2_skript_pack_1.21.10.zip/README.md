# Good Stuff v2 — adds `/menu` GUI hub (requires skript-gui for GUI)
