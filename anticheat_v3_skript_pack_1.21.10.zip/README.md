# Anti-Cheat v3 — tuned thresholds, warn→kick, verbose toggle
