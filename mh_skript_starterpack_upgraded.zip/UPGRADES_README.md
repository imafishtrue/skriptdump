# Starter Pack — Upgraded

This folder adds:
- `UPGRADES/Economy_GUI_v2` (Economy + AH GUI; skript-gui)
- `UPGRADES/AntiCheat_v3` (tuned checks, /acreload)
- `UPGRADES/GoodStuff_v2` (menu GUI + QoL)

**Install tips**
1. Backup your `plugins/Skript/scripts/` folder.
2. Copy desired upgrade subfolders into `plugins/Skript/scripts/` (keep structure).
3. Install **skript-gui** if using GUI files.
4. `/skript reload all`.
