# Economy GUI v2 (Paper 1.21.10, Skript 2.7+, skript-gui)

**What's new vs previous:**
- Added `/eco reload` to hot-reload economy files.
- Added **transaction log** (simple, in-memory rolling list).
- GUI polish: clearer names, back buttons, sound feedback.
- Config toggle: allow-negative, tax %, per-user listing cap, page sizes.
- Basic **dupe-safety** on AH listing remove/buy paths.

**Requires:** skript-gui (latest for 1.21.x)
